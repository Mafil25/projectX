from django.shortcuts import render, redirect
from registration.models import Users



def main(request):

    return render(request, 'main/main.html', {'completed_task' : 10})

