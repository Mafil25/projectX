from django.shortcuts import render

def page(request):
    return render(request, 'task/page-1.html')

# Create your views here.
